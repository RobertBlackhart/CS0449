Robert McDermot
rom66@pitt.edu
--------------------------------------

Compile with: gcc -Wall -m32 -std=c99 malloctest.c -o malloctest
Run with: ./malloctest

--------------------------------------

malloctest.c uses custom implementations of malloc() and free() as defined in mymalloc.h.  Output is printed to the console to track the state of the heap after corisponding malloc() and free() calls.

All of the functions in mymalloc.h are documented inline.
